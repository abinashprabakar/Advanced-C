#include<stdio.h>

int divide(int a, int b)
{
	return a/b;
}

int main()
{
	int x = 10, y = 2;
	int p = 8, q = 0;
	
	divide(x,y);
	divide(p,q);

	return 0;
}
